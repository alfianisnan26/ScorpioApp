#pragma once

#include <Windows.h>
#include <commdlg.h>

#ifndef _PROCEDURE_H
#define _PROCEDURE_H

// Message handler.
INT_PTR CALLBACK About(STD_PARAM_PROC)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_PAINT: {
		WinDrawText(GetVersionInfo(), hWnd, RGBBLACK, 15, FONT_STD_REG, 345, 315, 40, 40, TRUE, DT_NOCLIP | DT_SINGLELINE);
	}
		 return (INT_PTR)TRUE;
	case WM_INITDIALOG: {

		return (INT_PTR)TRUE;
	}
	case WM_COMMAND:
		if (LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hWnd, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK Proc_Wiz(STD_PARAM_PROC) {
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		return (INT_PTR)TRUE;
	}
	case WM_INITDIALOG: {

		return (INT_PTR)TRUE;
	}
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_SERVER:{
			hWndGlobal[IDW_CSERV] = DialogBox(hInst, MAKEINTRESOURCE(IDD_CREATE_SERVER), hWnd, Proc_CServ);
			ShowWindow(hWndGlobal[IDW_CSERV], SW_SHOW);
			break;
		}
		}
		return (INT_PTR)TRUE;
	default:
		return (INT_PTR)FALSE;
	}
	return (INT_PTR)TRUE;
}

INT_PTR CALLBACK Proc_Loading(STD_PARAM_PROC) {
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		return (INT_PTR)TRUE;
	}
	case WM_INITDIALOG: {

		return (INT_PTR)TRUE;
	}
	case WM_LOADING_DESTROY: {
		EndDialog(hWnd, LOWORD(wParam));
		return (INT_PTR)TRUE;
	}
	default:
		return (INT_PTR)FALSE;
	}
	return (INT_PTR)TRUE;
}

INT_PTR CALLBACK Proc_Const(STD_PARAM_PROC) {
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		return (INT_PTR)TRUE;
	}
	case WM_INITDIALOG: {
		thUpdate = TRUE;
		hThread[HTH_CONST] = CreateThread(0, 0, thUpdateConst, 0, 0, 0);
		return (INT_PTR)TRUE;
	}
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDC_BUTTON1: {
			thUpdate = FALSE;
			Sleep(10);
			TerminateThread(hThread[HTH_CONST], NULL);
			EndDialog(hWnd, LOWORD(wParam));
			break;
		}
		}
		return (INT_PTR)TRUE;
	default:
		return (INT_PTR)FALSE;
	}
	return (INT_PTR)TRUE;
}

INT_PTR CALLBACK Proc_CServ(STD_PARAM_PROC) {
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_CREATE: {
		break;
	}
	case WM_PAINT: {
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		return (INT_PTR)TRUE;
	}
	case WM_INITDIALOG: {
		hWndGlobal[IDW_COMBO_SERVER] = GetDlgItem(hWnd, IDC_COMBO2);
		SendMessage(hWndGlobal[IDW_COMBO_SERVER], CB_ADDSTRING, 0, (LPARAM)L"Static Constellation (0D)");
		SendMessage(hWndGlobal[IDW_COMBO_SERVER], CB_ADDSTRING, 0, (LPARAM)L"Linear Constellation (1D)");
		SendMessage(hWndGlobal[IDW_COMBO_SERVER], CB_ADDSTRING, 0, (LPARAM)L"Square Constellation (2D)");
		return (INT_PTR)TRUE;
	}
	case WM_COMMAND:
		if (HIWORD(wParam) == BN_CLICKED) {
			if (LOWORD(wParam) == IDC_BUTTON2) //Cancel
			{
				EndDialog(hWnd, LOWORD(wParam));
				return (INT_PTR)TRUE;
			}
			else if (LOWORD(wParam) == IDC_BUTTON1) //Create
			{
#ifndef _DEBUG_FIREBASE
				LPWSTR buf = (LPWSTR)calloc(sizeof(LPWSTR),32);
				int out = GetDlgItemText(hWnd, IDC_EDIT3, buf, 32);
				if (out <= 0 || out >= 32) {
					MessageBox(hWnd, L"Please Input Server Name (Max 32 Character)", L"Error", MB_OK | MB_ICONERROR);
					return(INT_PTR)TRUE;
				}
				else hServ.server_name = buf;
				int type = SendMessage(hWndGlobal[IDW_COMBO_SERVER], CB_GETCURSEL, 0, 0);
				if (type < 0) {
					MessageBox(hWnd, L"Please Select Constellation Type", L"Error", MB_OK | MB_ICONERROR);
					return(INT_PTR)TRUE;
				}
				else {
					hServ.type = type;
				}
				bool bSuccess = FALSE;         // variable for checking success
				int num = GetDlgItemInt(hWnd, IDC_EDIT4, &bSuccess, FALSE); // Get the number from IDC_NUM1
				if (bSuccess == FALSE) {    // If couldn't get value....
					MessageBox(hWnd, L"Please Input Maximum Client Value!", L"Error", MB_OK | MB_ICONERROR);
					return (INT_PTR)TRUE;
				}
				else if (bSuccess == TRUE) {
					hServ.max_client = num;
				}
#endif
				int x = inetCheck(hWnd);
				if (x == TRUE) {
					EndDialog(hWnd, LOWORD(wParam));
					if (IsWindowVisible(hWndGlobal[IDW_WIZ]) == TRUE) {
						ShowWindow(hWndGlobal[IDW_WIZ], SW_HIDE);
					}
				}
				return (INT_PTR)TRUE;
			}
		}
		if (LOWORD(wParam) == IDC_COMBO2) {
			if (HIWORD(wParam) == CBN_SELENDOK) {
			}
		}
		break;
	}
	return (INT_PTR)FALSE;
}

#define SHOW_QR 0xF260
LRESULT CALLBACK Proc_QR(STD_PARAM_PROC) {
	HBITMAP g_hbmBall = 0;
	switch (message) {
	case WM_COMMAND:
		break;
	case WM_CREATE: {
		
	}
	break;
	case WM_PAINT:
	{
		RECT rect;
		GetWindowRect(hWnd, &rect);
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
	}
	break;
	case WM_DESTROY:
		ShowWindow(hWnd, SW_HIDE);
		hWndGlobal[IDW_QRVIEWER] = NULL;
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;

}

LRESULT CALLBACK Proc_TextViewer(STD_PARAM_PROC) {
	switch (message) {
	case WM_CREATE:{

	}
	case WM_PAINT:{

	}
	case WM_DESTROY: {
		ShowWindow(hWnd, SW_HIDE);
		hWndGlobal[IDW_TEXTVIEWER] = NULL;
		break;
	}
	case WM_SIZING: {

		break;
	}
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

//  PURPOSE: Processes messages for the main window.
LRESULT CALLBACK WndProc(STD_PARAM_PROC){
	HBITMAP g_hbmBall = 0;
	switch (message)
	{
	case WM_CREATE: {
		hWndGlobal[IDW_WIZ] = CreateDialog(hInst, MAKEINTRESOURCE(IDD_FORMVIEW), hWnd, Proc_Wiz);
		UpdateWindow(hWndGlobal[IDW_WIZ]);
		break;
	}
	case WM_SIZE: {
		UpdateWindow(hWndGlobal[IDW_WIZ]);
	}
	case WM_COMMAND:
	{
		int wmId = LOWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case ID_SEQUENCE_OPEN: {
			WinFileDialog(OPEN);
			break;
		}
		case ID_SEQUENCE_SAVE: {
			WinFileDialog(SAVE);
			break;
		}
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_RST:
			break;
		case ID_SERVERID_QRCODE:
			if (hWndGlobal[IDW_QRVIEWER] == NULL) {
				qr_G = MakeBitmapQR(FCH("https://%s/join/%d", STD_LINK2, hServ.server_id), 10);
				hWndGlobal[IDW_QRVIEWER] = CreateWindowEx(
					WS_EX_TOPMOST ,                              // Optional window styles.
					CLASS_STD_WND,                     // Window class
					L"QR Viewer",    // Window text
					WS_OVERLAPPED | WS_SYSMENU | WS_THICKFRAME ,            // Window style

					// Size and position
					CW_USEDEFAULT, CW_USEDEFAULT, qr_G.RealSize + 75, qr_G.RealSize + 98,

					NULL,       // Parent window    
					NULL,       // Menu
					hInst,  // Instance handle
					NULL        // Additional application data
				);
				qr_G.hWnd = CreateWindow(L"STATIC", NULL, WS_VISIBLE | WS_CHILD | SS_BITMAP, 30, 30, 300, 300, hWndGlobal[IDW_QRVIEWER], 0, 0, 0);
				SendMessageW(qr_G.hWnd, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)qr_G.ptrQR);
				ShowWindow(hWndGlobal[IDW_QRVIEWER], SW_SHOW);
				UpdateWindow(hWndGlobal[IDW_QRVIEWER]);
			}
			else {
				ShowWindow(hWndGlobal[IDW_QRVIEWER], SW_HIDE);
				hWndGlobal[IDW_QRVIEWER] = NULL;
			}
			break;
		case ID_SERVERID_TEXT:
		{
			ClipboardCopy(FCH("%s/join/%d", STD_LINK, hServ.server_id));
			MessageBox(hWnd, LFCH("Link : \"%s/join/%d\" has copied to clipboard.", STD_LINK, hServ.server_id), L"Link Copied", MB_OK);
			if (hWndGlobal[IDW_TEXTVIEWER] == NULL) {
				hWndGlobal[IDW_TEXTVIEWER] = CreateWindowEx(
					WS_EX_TOPMOST,                              // Optional window styles.
					CLASS_STD_WND,                     // Window class
					L"Server ID Viewer",    // Window text
					WS_OVERLAPPED | WS_SYSMENU | WS_CAPTION | WS_VISIBLE,            // Window style

					// Size and position
					CW_USEDEFAULT, CW_USEDEFAULT, 600 + STD_X, 250 + STD_Y,

					NULL,       // Parent window    
					NULL,       // Menu
					hInst,  // Instance handle
					NULL        // Additional application data
				);
				WinDrawText(FINTCH(hServ.server_id), hWndGlobal[IDW_TEXTVIEWER], RGBBLACK, 200, FONT_STD_BOLD, 0, 0, 600 , 200, TRUE, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
				WinDrawText("Or Join by URL Link bellow", hWndGlobal[IDW_TEXTVIEWER], RGBBLACK, 20, FONT_STD_BOLD, 0, 180, 600, 30, TRUE, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
				WinDrawText(FCH("%s/join/%d",STD_LINK,hServ.server_id), hWndGlobal[IDW_TEXTVIEWER], RGBBLACK, 30, FONT_STD_BOLD, 0, 200, 600 , 30, TRUE, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
			}
			else {
				ShowWindow(hWndGlobal[IDW_TEXTVIEWER], SW_HIDE);
				hWndGlobal[IDW_TEXTVIEWER] = NULL;
			}
			break;
		}
		case ID_FILE_RESET:
		case ID_FILE_CREATESERVER: {
			hWndGlobal[IDW_CSERV] = DialogBox(hInst, MAKEINTRESOURCE(IDD_CREATE_SERVER), hWnd, Proc_CServ);
			ShowWindow(hWndGlobal[IDW_CSERV], SW_SHOW);
			break;
		}
		case ID_DCLIENT: system(FCH("start %s", STD_LINK));
			break;
		case IDM_EXIT:
			if (hRequest) WinHttpCloseHandle(hRequest);
			if (hConnect) WinHttpCloseHandle(hConnect);
			if (hSession) WinHttpCloseHandle(hSession);
			PostQuitMessage(0);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
	}
	break;
	case WM_PAINT:
	{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);
			EndPaint(hWnd, &ps);
	}
	break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK SplashWndProc(STD_PARAM_PROC)
{
	switch (message)
	{
	case WM_PAINT: {
		BitBlt(hSplashDC, 0, 0, BitmapWidth, BitmapHeight, hMemoryDC, 0, 0, SRCCOPY);
		WinDrawText(GetVersionInfo(), hWnd, RGBWHITE, 15, FONT_STD_ITALIC, 570, 325, 40, 40, TRUE, DT_NOCLIP | DT_SINGLELINE);
	}
	default:
		return (DefWindowProc(hWnd, message, wParam, lParam));
	}
	return 0;
}

LRESULT CALLBACK MyStaticWndProc(HWND hwnd, UINT Message, WPARAM wparam, LPARAM lparam)
{
	if (Message == WM_PAINT)
	{
		int a = 0;
		for (a = 0; a < 128; a++) {
			if (hText_G[a].hTWnd == hwnd) break;
		}
		LPCWSTR str = hText_G[a].text;
		RECT rc;
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
		GetClientRect(hwnd, &rc);
		if (hText_G[a].ts == TRUE) SetBkMode(hdc, TRANSPARENT);
		SetTextColor(hdc, hText_G[a].c);
		HFONT hFont, hOldFont;
		hFont = CreateFont(hText_G[a].fSze, 0, 0, 0, FW_DONTCARE, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_SWISS, hText_G[a].fName);
		if (hOldFont = (HFONT)SelectObject(hdc, hFont))
		{
			DrawText(hdc, str , wcslen(str), &rc, hText_G[a].Uformat);
			SelectObject(hdc, hOldFont);
		}
		DeleteDC(hdc);
		EndPaint(hwnd, &ps);
		return 0;
	}
	else if (Message == TEXT_SET_STRING) {

	}

	//v2 StaticWndProc(hwnd, Message, wparam, lparam);
	return CallWindowProc(StaticWndProc, hwnd, Message, wparam, lparam); //v2
}

#endif // !1

